﻿# Computer Fundamentals

A computer processes data according to instructions.

## Main components

- CPU: Executes instructions.
- RAM: Temporary working memory.
- Storage: Keeps data.
- Motherboard: Connects components.
- Input devices: Send information.
- Output devices: Present information.

## Exercise

Explain the difference between RAM and storage.
