﻿# Operating Systems

An operating system manages computer resources.

## Responsibilities

- Process management
- Memory management
- File management
- Device management
- Security
- User interface

Examples include Windows, Linux, macOS and Android.

## Exercise

Explain why applications need an operating system.
