﻿# Computer Networks

A computer network connects devices to exchange information.

## Concepts

- IP address
- Router
- Switch
- DNS
- HTTP
- HTTPS
- TCP
- UDP

## Client and server

A client requests a resource.
A server processes the request and responds.

## Exercise

Explain what happens when you open a website.
