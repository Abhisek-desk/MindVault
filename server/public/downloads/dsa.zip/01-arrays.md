﻿# Arrays

An array stores elements in an ordered collection.

## Operations

- Access
- Insert
- Delete
- Search
- Update

Access by index is generally O(1).

Searching an unsorted array is O(n).

## Exercise

Find the largest element in an array.
