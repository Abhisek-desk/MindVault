﻿# Linked Lists

A linked list contains nodes connected through references.

Each node stores:

- Data
- Reference to the next node

## Common operations

- Insert
- Delete
- Traverse
- Search

A singly linked list supports traversal in one direction.

## Exercise

Draw a linked list containing five nodes.
