﻿# Stacks and Queues

## Stack

A stack follows LIFO: Last In, First Out.

Operations:

- Push
- Pop
- Peek

## Queue

A queue follows FIFO: First In, First Out.

Operations:

- Enqueue
- Dequeue
- Front

## Exercise

Describe how a browser's back button can use a stack.
