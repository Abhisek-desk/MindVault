﻿# Algorithm Complexity

Big O notation describes how an algorithm scales.

## Common complexities

- O(1): Constant
- O(log n): Logarithmic
- O(n): Linear
- O(n log n): Linearithmic
- O(nÂ²): Quadratic

## Exercise

Compare linear search and binary search.
Explain why binary search requires sorted data.
