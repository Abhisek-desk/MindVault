﻿# JavaScript Basics

JavaScript adds behaviour and interactivity to websites.

## Variables

    const name = "Mind Vault";
    let score = 10;

Use const by default and let when reassignment is needed.

## Data types

- String
- Number
- Boolean
- Undefined
- Null
- Object
- Array

## Exercise

Create variables for your name, age and favourite programming language.
