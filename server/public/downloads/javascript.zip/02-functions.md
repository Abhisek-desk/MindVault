﻿# JavaScript Functions

Functions are reusable blocks of code.

## Function declaration

    function greet(name) {
      return "Hello " + name;
    }

## Arrow function

    const add = (a, b) => a + b;

## Exercise

Write a function that calculates the area of a rectangle.
