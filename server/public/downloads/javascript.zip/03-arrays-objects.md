﻿# Arrays and Objects

## Arrays

    const languages = ["JavaScript", "Python", "Java"];

Access an item using its index:

    console.log(languages[0]);

## Objects

    const student = {
      name: "Alex",
      age: 20
    };

Access a property:

    console.log(student.name);

## Exercise

Create an array of three student objects.
