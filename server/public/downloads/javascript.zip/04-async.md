﻿# Asynchronous JavaScript

Asynchronous operations allow work to continue without blocking the main thread.

## Promise

    const task = Promise.resolve("Completed");

## Async and await

    async function loadData() {
      const response = await fetch("/api/data");
      return response.json();
    }

## Exercise

Write an async function that fetches data from a public API.
