﻿# Python Introduction

Python is a general-purpose programming language.

## Hello World

    print("Hello, World!")

## Variables

    name = "Alex"
    age = 20

## Data types

- str
- int
- float
- bool
- list
- tuple
- dict

## Exercise

Write a program that displays your name and age.
