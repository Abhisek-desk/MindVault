﻿# Conditions and Loops

## Conditions

    age = 18

    if age >= 18:
        print("Adult")
    else:
        print("Minor")

## For loop

    for number in range(5):
        print(number)

## While loop

    count = 0

    while count < 5:
        print(count)
        count += 1

## Exercise

Print all even numbers from 1 to 50.
