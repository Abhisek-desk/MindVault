﻿# Python Functions

Functions organize reusable code.

## Example

    def greet(name):
        return f"Hello {name}"

    print(greet("Alex"))

## Default arguments

    def welcome(name="Student"):
        print(f"Welcome {name}")

## Exercise

Create a function that returns the largest of three numbers.
