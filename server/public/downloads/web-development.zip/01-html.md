﻿# HTML Fundamentals

HTML structures web pages.

## Basic document

    <!DOCTYPE html>
    <html>
      <head>
        <title>My Website</title>
      </head>
      <body>
        <h1>Hello World</h1>
        <p>My first webpage.</p>
      </body>
    </html>

## Important elements

- h1 to h6: Headings
- p: Paragraph
- a: Link
- img: Image
- ul and ol: Lists
- div: Container
- form: User input

## Exercise

Create a webpage containing a heading, paragraph and link.
