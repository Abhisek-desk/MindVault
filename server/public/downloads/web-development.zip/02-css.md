﻿# CSS Fundamentals

CSS controls the appearance of HTML pages.

## Example

    body {
      font-family: Arial, sans-serif;
      background: #f5f5f5;
    }

    h1 {
      color: navy;
    }

## Box model

Every HTML element can have:

- Content
- Padding
- Border
- Margin

## Exercise

Create a card with a background, padding and rounded corners.
