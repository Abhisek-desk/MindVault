﻿# Responsive Web Design

Responsive design makes websites work on different screen sizes.

## Viewport

Add this inside the HTML head:

    <meta name="viewport" content="width=device-width, initial-scale=1">

## Media query

    @media (max-width: 600px) {
      .container {
        padding: 12px;
      }
    }

## Best practices

- Use flexible layouts.
- Avoid fixed widths where possible.
- Test mobile screens.
- Make buttons easy to tap.

## Exercise

Create a two-column layout that becomes one column on mobile.
